# GNU screen Puppet Module for Boxen

## Usage

```puppet
include screen
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
