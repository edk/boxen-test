# Swig Puppet Module for Boxen

## Usage

```puppet
include swig
```

## Required Puppet Modules

* `boxen`
* `pcre`
