# GPGme Puppet Module for Boxen

Install [GPGme](http://www.gnupg.org/related_software/gpgme), a crypto API.

## Usage

```puppet
include gpgme
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
