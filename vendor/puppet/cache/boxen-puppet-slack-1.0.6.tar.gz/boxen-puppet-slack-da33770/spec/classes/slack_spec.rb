require 'spec_helper'

describe 'slack' do
  it do
  end
end
